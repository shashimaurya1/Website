VERSION = (0, 6, 0,)
__version__ = '.'.join(map(str, VERSION))
default_app_config = 'django_messages.apps.DjangoMessagesConfig'
