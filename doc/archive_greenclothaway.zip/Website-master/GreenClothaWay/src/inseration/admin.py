# posts/admin.py
from django.contrib import admin

from .models import Inseration

admin.site.register(Inseration)
