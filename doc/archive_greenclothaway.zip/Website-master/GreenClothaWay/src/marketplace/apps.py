from django.apps import AppConfig
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin


class FrontendConfig(AppConfig):
    name = 'marketplace'

